Plugins for WolfCMS
Web Form for mails.
Version 1.0.0 22.2.2012 (c) by Fredy Mettler

23.2.2012 Version update 1.0.1 security check (stip_tags)

Unzip the files and save the folder fm_contact under yoursite/wolf/plugins/

